import java.util.Scanner;
public class Main {
    public void main(String[] args) {
        UI main=new UI();
        UI.start();
    }
}