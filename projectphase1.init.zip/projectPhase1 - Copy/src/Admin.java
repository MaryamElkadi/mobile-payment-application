import java.util.Scanner;
public class Admin implements approv
{
    public String Password;
    public transaction arr[];

    public Admin() {
        // TODO Auto-generated constructor stub
        //AEmail=" ";
        Password="Admin";
        arr=new transaction[50];
        for(int i=0;i<50;i++){
            arr[i].Amount=0;
            arr[i].transactiontype=" ";
            arr[i].servicetype=" ";
        }
    }

    @Override
    public void Transaction() {
        for(int i=0;i<50;i++){
            if(arr[i].ok==false && arr[i].transactiontype=="refund transaction"){
                System.out.println(arr[i].user1.username+ "  " +arr[i].Amount + "  " +arr[i].servicetype );
                System.out.println("1-accept" +
                        "2-reject");
                Scanner scan =new Scanner(System.in);
                int choice = scan.nextInt();
                if(choice==1){
                    approv newrefund=new refund(arr[i].Amount,arr[i].user1);
                    newrefund.Transaction();
                    arr[i].ok=true;
                }
                else if(choice==2){
                    continue;
                }
            }
        }
    }

}
