import java.util.Scanner;

public class Donations implements service {
    @Override
    public void print(user user1, adminController admin) {
            System.out.println("choose service type:" +
                    "1-Cancer Hospital" +
                    "2-Schools" +
                    "3-NGOs (non profitable organizations)" );
            Scanner scan =new Scanner(System.in);
            int int1 = scan.nextInt();
            String type=" ";
            if(int1==1){
                type="Cancer Hospital";
            }
            else if(int1==2){
                type="Schools";
            }
            else if(int1==3){
                type="NGOs";
            }
            System.out.println("Enter the amount:");
            double amount = scan.nextDouble();
            transaction pay1=new payment(amount,user1,type);
            pay1.Transaction();
            admin.add(pay1);
    }

    /*
   private  String CancerHospital;
    private  String Schools;
    private  String NGOs;

    public void setCancerHospitalt(Double c)
    {CancerHospital= String.valueOf(c);}
    public String getCancerHospital (){return CancerHospital;}

    public void setSchools(Double s)
    {Schools= String.valueOf(s);}
    public String getSchools (){return Schools;}

    public void setNGOs(Double n)
    {NGOs= String.valueOf(n);}
    public String getNGOs (){return NGOs;}

    public void print()
    {
        if(getCancerHospital()=="cancer hospital")
        {System.out.println("you are in Donations service cancer hospital"+getCancerHospital());}
        else if
        (getSchools()=="schools")
        {System.out.println("you are in donations service schools"+getSchools());}
        else if
        (getNGOs()=="NGOs")
        {System.out.println("you are in donations service NGOs"+getNGOs());}
    };*/
}
