public class Overalldiscounts extends Discount {
    private double value;
    public void setValue(double v)
    {value=v;}
    public double getValue()
    {return value;}
    public void addDiscount(double value)
    {System.out.print("Add Discount succssefully"+getValue());
    }
}
