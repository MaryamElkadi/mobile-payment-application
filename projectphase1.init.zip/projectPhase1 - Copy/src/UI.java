import java.util.Scanner;
public class UI {
    userController control;
    adminController admin;
    user useron;
    public UI(){
        control=new userController();
        admin=new adminController();
        useron=new user();
    }
    public void start(){
        System.out.println("1-sign in" +
                "2-sign up" +
                "3-enter as admin");
        Scanner scan =new Scanner(System.in);
        int int1 = scan.nextInt();
        switch(int1){
            case 1:
                System.out.println("enter user email:");
                Scanner scan1 =new Scanner(System.in);
                String str1 = scan.next();
                System.out.println("enter user password:");
                Scanner scan2 =new Scanner(System.in);
                String str2 = scan.next();
                int res=control.signIn(str1,str2);
                user useron=new user();
                useron=userController.arr[res];
                this.useron=useron;
                choose();
                break;
            case 2:
                System.out.println("enter user email:");
                Scanner scan3 =new Scanner(System.in);
                String str3 = scan.next();
                System.out.println("enter user password:");
                Scanner scan4 =new Scanner(System.in);
                String str4 = scan.next();
                System.out.println("enter user username:");
                Scanner scan5 =new Scanner(System.in);
                String str5 = scan.next();
                int resu=control.signUp(str5,str3,str4);
                user useron1=new user();
                useron=userController.arr[resu];
                useron=useron1;
                choose();
                break;
            case 3:
                System.out.println("enter admin password:");
                Scanner scan6 =new Scanner(System.in);
                String str6 = scan.next();
                boolean tf=admin.check(str6);
                if(tf){
                    System.out.println("choose from the following:" +
                            "1-add a discount" +
                            "2-list all user transactions" +
                            "3-list refund requests ");
                    Scanner scan7 =new Scanner(System.in);
                    int int7= scan.nextInt();
                    switch (int7){
                        case 1:
                            break;
                        case 2:
                            admin.list();
                            break;
                        case 3:
                            admin.approve();
                            break;
                    }
                }
                else{
                    System.out.println("failed to sign in as admin");
                }

        }
    }
    public void choose(){
        System.out.println("choose what you want to do:" +
                "1-seacrh for a service" +
                "2-pay" +
                "3-refund" +
                "4-check discounts");
        Scanner scan10 =new Scanner(System.in);
        int str10 = scan10.nextInt();
        switch(str10){
            case 1:
                System.out.println("Enter service name in lower case letters");
                Scanner scan12 =new Scanner(System.in);
                String str12 = scan10.nextLine();
                String res=control.search(str12);
                System.out.println(res);
                break;
            case 2:
                System.out.println("choose the services type:" +
                        "1-mobile recharge services" +
                        "2-internet payment services" +
                        "3-landline services" +
                        "4-donations");
                Scanner scan11 =new Scanner(System.in);
                int int11 = scan11.nextInt();
                control.payment(useron,int11,admin);
                break;
            case 3:
                System.out.println("Enter the transaction amount: ");
                Scanner scan13 =new Scanner(System.in);
                double int13 = scan13.nextDouble();
                control.refundrequest(admin,useron,int13);
                break;
            case 4:
                break;
        }
    }
}
