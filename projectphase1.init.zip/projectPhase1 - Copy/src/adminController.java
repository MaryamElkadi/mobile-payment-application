public class adminController {
    public Admin a;
    public adminController(){
        a=new Admin();
    }

    public boolean check(String s){
        if(a.Password==s){
            return true;
        }
        return false;
    }

    public void add(transaction trans){
        for(int i=0;i<50;i++){
            if(a.arr[i].transactiontype==" "){
                a.arr[i]=trans;
                break;
            }
        }
    }

    public void approve(){
        a.Transaction();
    }

    public void list(){
        for(int i=0;i<50;i++){
            System.out.println(a.arr[i].user1.username+"    "+a.arr[i].transactiontype+"   "+a.arr[i].Amount);
        }
    }

    public void refund(user user1,double amount){
        for(int i=0;i<50;i++){
            if(user1==a.arr[i].user1 && amount==a.arr[i].Amount){
                transaction refund1=new refund(amount,user1);
                for(int j=0;j<50;j++){
                    if(a.arr[j].transactiontype==" "){
                        a.arr[j]=refund1;
                        break;
                    }
                }
                break;
            }
        }
    }
}
