public class Discount {
    transaction t;
    service s;

    public double addDiscount(transaction t,service s)
    {return 0;
    };

}
