public interface approv {
    public void Transaction();
}
