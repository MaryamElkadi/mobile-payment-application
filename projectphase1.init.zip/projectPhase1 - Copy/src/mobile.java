import java.util.Scanner;

public class mobile implements service {
    @Override
    public void print(user user1,adminController admin)
    {
        System.out.println("choose service type:" +
                "1-Vodafone" +
                "2-Orange" +
                "3-Etisalat" +
                "4-We");
        Scanner scan =new Scanner(System.in);
        int int1 = scan.nextInt();
        String type=" ";
        if(int1==1){
            type="Vodafone";
        }
        else if(int1==2){
            type="Orange";
        }
        else if(int1==3){
            type="Etisalat";
        }
        else if (int1==4) {
            type = "We";
        }
        System.out.println("enter the amount:");
        double amount = scan.nextDouble();
        transaction pay1=new payment(amount,user1,type);
        pay1.Transaction();
        admin.add(pay1);


}}
