import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        UI m = new UI();
        m.start();

    }
}