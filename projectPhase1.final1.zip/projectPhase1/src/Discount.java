public abstract class Discount extends transaction {
    public String service;
    public double percent;
    public transaction t;

    public Discount(){
        service=" ";
        percent=0.0;
    }

    public Discount(String service,double percent){
        this.service=service;
        this.percent=percent;
    }
}
