public class spacific extends Discount{
    public spacific(String s, double percent) {
            this.service=service;
            this.percent=percent;
        }

    @Override
    public void Transaction() {

    }
}

