public interface service {

  public void print(user user1,adminController admin);

}
