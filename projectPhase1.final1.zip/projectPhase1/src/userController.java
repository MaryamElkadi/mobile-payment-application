public class userController {
    public static user[] arr;

    public userController() {
        arr = new user[50];
    }

    public boolean check(String Email) {
        for (int i = 0; i < 50; i++) {
            if (Email == arr[i].Email) {
                return true;
            }
        }
        return false;
    }

    public int signIn(String Email, String Password) {
        for (int i = 0; i < 50; i++)
            if (Email == arr[i].Email && Password == arr[i].Password) {
                return i;
            }

        return -1;
    }

    public int signUp(String username, String Email, String Password) {
        if (!check(Email)) {
            for (int i = 0; i < 50; i++) {
                if (arr[i].username == " ") {
                    arr[i].setInfo(username, Email, Password);
                    return i;
                }
            }
        }
        return -1;
    }

    public void addtowallet(user user1,double amount) {
        user1.wallet+=amount;
    }

    public void payment(user user1, int i, adminController admin) {
        switch (i) {
            case 1:
                serviceForm form1 = new mobileform();
                form1.showform(user1, admin);
                break;
            case 2:
                serviceForm form2 = new internetform();
                form2.showform(user1, admin);
                break;
            case 3:
                serviceForm form3 = new landlineForm();
                form3.showform(user1, admin);
                break;
            case 4:
                serviceForm form4 = new donationform();
                form4.showform(user1, admin);
                break;
        }
    }

    public String search(String str) {
        switch (str) {
            default:
                return "service does not exist";

            case "mobile":
                return "mobile recharge services";

            case "internet":
                return "internet payment services";

            case "landline":
                return "landline services";

            case "donations":
                return "donations";

        }
    }


    public void refundrequest(adminController admin,user user1,double amount){
        admin.refund(user1,amount);
    }


};
