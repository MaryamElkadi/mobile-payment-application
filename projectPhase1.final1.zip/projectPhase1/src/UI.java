import java.util.Scanner;
public class UI {
    public userController control;
    public adminController admin;
    public user useron;
    public UI(){
        control=new userController();
        admin=new adminController();
        useron=new user();
    }
    public void start(){
        System.out.println("1-sign in\n" +
                "2-sign up\n" +
                "3-enter as admin\n");
        Scanner scan =new Scanner(System.in);
        int int1 = scan.nextInt();
        switch(int1){
            case 1:
                System.out.println("enter user email:\n");
                Scanner scan1 =new Scanner(System.in);
                String str1 = scan.next();
                System.out.println("enter user password:\n");
                Scanner scan2 =new Scanner(System.in);
                String str2 = scan.next();
                int res=control.signIn(str1,str2);
                user useron=new user();
                useron=userController.arr[res];
                this.useron=useron;
                choose();
                break;
            case 2:
                System.out.println("enter user email:\n");
                Scanner scan3 =new Scanner(System.in);
                String str3 = scan.next();
                System.out.println("enter user password:\n");
                Scanner scan4 =new Scanner(System.in);
                String str4 = scan.next();
                System.out.println("enter user username:\n");
                Scanner scan5 =new Scanner(System.in);
                String str5 = scan.next();
                int resu=control.signUp(str5,str3,str4);
                user useron1=new user();
                useron=userController.arr[resu];
                useron=useron1;
                choose();
                break;
            case 3:
                System.out.println("enter admin password:\n");
                Scanner scan6 =new Scanner(System.in);
                String str6 = scan.next();
                boolean tf=admin.check(str6);
                if(tf){
                    System.out.println("choose from the following:\n" +
                            "1-add a discount\n" +
                            "2-list all user transactions\n" +
                            "3-list refund requests \n");
                    Scanner scan7 =new Scanner(System.in);
                    int int7= scan.nextInt();
                    switch (int7){
                        case 1:
                            System.out.println("choose the discount type :\n" +
                                    "1-spacific discount\n" +
                                    "2-ovarall discount\n");
                            Scanner scan10 =new Scanner(System.in);
                            int int10= scan10.nextInt();
                            System.out.println("choose the services to add a discount on :\n" +
                                    "1-mobile recharge services\n" +
                                    "2-internet payment services\n" +
                                    "3-landline services\n" +
                                    "4-donations\n");
                            Scanner scan8 =new Scanner(System.in);
                            int int8= scan8.nextInt();
                            System.out.println("enter the dicount percent: \n");
                            Scanner scan9 =new Scanner(System.in);
                            int int9= scan9.nextInt();
                            switch (int8){
                                case 1:
                                    admin.adddiscount("mobile recharge",int10,int9/100);
                                    break;
                                case 2:
                                    admin.adddiscount("internet payment",int10,int9/100);
                                    break;
                                case 3:
                                    admin.adddiscount("landline",int10,int9/100);
                                    break;
                                case 4:
                                    admin.adddiscount("donations",int10,int9/100);
                                    break;
                            }
                            break;
                        case 2:
                            admin.list();
                            break;
                        case 3:
                            admin.approve();
                            break;
                    }
                }
                else{
                    System.out.println("failed to sign in as admin");
                }
                break;
        }
    }
    public void choose(){
        System.out.println("choose what you want to do:\n" +
                "1-seacrh for a service\n" +
                "2-pay\n" +
                "3-refund\n" +
                "4-check discounts\n" +
                "5-add to wallet\n");
        Scanner scan10 =new Scanner(System.in);
        int str10 = scan10.nextInt();
        switch(str10){
            case 1:
                System.out.println("Enter service name in lower case letters :\n");
                Scanner scan12 =new Scanner(System.in);
                String str12 = scan10.nextLine();
                String res=control.search(str12);
                System.out.println(res);
                break;
            case 2:
                System.out.println("choose the services type:\n" +
                        "1-mobile recharge services\n" +
                        "2-internet payment services\n" +
                        "3-landline services\n" +
                        "4-donations\n");
                Scanner scan11 =new Scanner(System.in);
                int int11 = scan11.nextInt();
                control.payment(useron,int11,admin);
                break;
            case 3:
                System.out.println("Enter the transaction amount:\n ");
                Scanner scan13 =new Scanner(System.in);
                double int13 = scan13.nextDouble();
                control.refundrequest(admin,useron,int13);
                break;
            case 4:

                break;
            case 5:
                System.out.println("Enter the amount you want to add:\n ");
                Scanner scan14 =new Scanner(System.in);
                double int14 = scan14.nextDouble();
                control.addtowallet(useron,int14);
                System.out.println("amount addded to wallet from credit card");
        }
    }
}
