public class ovarall extends Discount{
    public ovarall(String service,double percent){
        this.service=service;
        this.percent=percent;
    }

    @Override
    public void Transaction() {

    }
}
