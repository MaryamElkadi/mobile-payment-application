public interface serviceForm {
    public void showform(user user1,adminController admin);
}