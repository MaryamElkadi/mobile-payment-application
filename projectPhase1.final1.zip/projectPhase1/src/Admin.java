import java.util.Scanner;
public class Admin implements approv
{
    public String Password;
    public transaction arr[];
    public Discount d[];


    public Admin() {
        d=new Discount[50];
        Password="Admin";
        arr=new transaction[50];
        for(int i=0;i<50;i++){
            arr[i].transactiontype=" ";
            arr[i].servicetype=" ";
            d[i].percent=0.0;
            d[i].service=" ";
        }
    }

    @Override
    public void Transaction() {
        for(int i=0;i<50;i++){
            if(arr[i].ok==false && arr[i].transactiontype=="refund transaction"){
                System.out.println(arr[i].user1.username+ "  " +arr[i].Amount + "  " +arr[i].servicetype );
                System.out.println("1-accept\n" +
                        "2-reject\n");
                Scanner scan =new Scanner(System.in);
                int choice = scan.nextInt();
                if(choice==1){
                    approv newrefund=new refund(arr[i].Amount,arr[i].user1);
                    newrefund.Transaction();
                    arr[i].ok=true;
                }
                else if(choice==2){
                    continue;
                }
            }
        }
    }

}
